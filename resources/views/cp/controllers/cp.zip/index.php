<?php
include"../includes/autoloads.php";
session_start();
if (!isset($_SESSION['username'])) {
    include "controllers/c_login.php";
    die();
}


?>
<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>IEEE-MSB control panel</title>
    <link rel="icon" href="../resources/images/title-logo.png">
    <!-- to make html5 readable on old browsers-->
    <script src="../resources/js/html5shiv.min.js"></script>

    <link rel="stylesheet" type="text/css" href="../resources/css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="../resources/includes/font-awesome-4.3.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" type="text/css" href="../resources/css/cp-style.css"/>
</head>
<body id="top">
<h1 class="text-center"><span class="ieee">IEEE</span>-MSB control panel </h1>
<?php
if (isset($_SESSION['username'])) {

    echo "<div class='pull-right logout'>" . $_SESSION['username'] . "<a href='?logout=logout' style='text-decoration:none;'> logout </a></div>";

}
?>

<!--up arrow-->
<div class="fixed-arrow">
    <a href="#top"><i class="fa fa-arrow-circle-up"></i></a>
</div>

<div class="clearfix"></div>


<div class="container margt">


    <section class="cp">
        <div class="row">
            <aside class="col-xs-3">
                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                    <!--           item strat ---------------------------------------------------------->
                    <div class="panel panel-default">
                        <div class="panel-heading collapsed" id="headingOne" role="button" data-toggle="collapse"
                             data-parent="#accordion" href="#collapseOne"
                             aria-expanded="false" aria-controls="collapseOne">
                            <h4 class="panel-title">
                                Events
                            </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse" role="tabpanel"
                             aria-labelledby="headingOne" aria-expanded="false">
                            <div class="panel-body">
                                <!--                            sub items-->
                                <div><a href="?event=eventhome">Event Home </a></div>
                                <div><a href="?event=addevent">Add Event </a></div>

                            </div>
                        </div>
                    </div>
                    <!--           item end -------------------------------------------------------------> <!--           item strat ---------------------------------------------------------->
                    <div class="panel panel-default">
                        <div class="panel-heading collapsed" id="headingFour" role="button" data-toggle="collapse"
                             data-parent="#accordion" href="#collapseFour"
                             aria-expanded="false" aria-controls="collapseOne">
                            <h4 class="panel-title">
                               Volunteers
                            </h4>
                        </div>
                        <div id="collapseFour" class="panel-collapse collapse" role="tabpanel"
                             aria-labelledby="headingFour" aria-expanded="false">
                            <div class="panel-body">
                                <!--                            sub items-->
                                <div><a href="?volunteers=volunteershome">Volunteers Home </a></div>
                                <div><a href="?volunteers=addvolunteers">Add Volunteers </a></div>

                            </div>
                        </div>
                    </div>
                    <!--           item end ------------------------------------------------------------->
                    <!--           item strat ---------------------------------------------------------->
                    <div class="panel panel-default">
                        <div class="panel-heading collapsed" id="headingThree" role="button" data-toggle="collapse"
                             data-parent="#accordion" href="#collapseThree"
                             aria-expanded="false" aria-controls="collapseThree">
                            <h4 class="panel-title">
                                Tool
                            </h4>
                        </div>
                        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel"
                             aria-labelledby="headingThree" aria-expanded="false">
                            <div class="panel-body">
                                <!--               sub items    -->
                                <div><a href="?event=checkimages">delete junk event images</a></div>
                                <div><a href="?volunteers=checkimages">delete junk volunteers images</a></div>

                            </div>
                        </div>
                    </div>
                    <!--           item end ------------------------------------------------------------->


                </div>
            </aside>

            <div class="page col-xs-9">
                <!-- includes-->

                <?php
                if (!isset($_GET)) {

                }elseif(isset($_GET['home'])){
                  header("Location:../cp");
                }
                elseif (isset($_GET['logout'])) {

                    include "controllers/c_logout.php";
                } elseif (isset($_GET['event'])) {
                    include "controllers/c_events.php";
                }
                elseif (isset($_GET['volunteers'])) {

                    include "controllers/c_about.php";
                }

                ?>

            </div>
        </div>

    </section>

    <div class="clearfix"></div>
    <footer>
        <p>
            copyright &copy reserved to abdelmnem samy
        </p>
    </footer>
</div>


<script src="../resources/js/jqeury.js">
</script>
<script src="../resources/js/plugin.js"></script>
<script src="../resources/js/bootstrap.min.js"></script>
</body>
</html>

