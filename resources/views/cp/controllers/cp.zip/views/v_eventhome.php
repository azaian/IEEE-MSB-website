<h3>events </h3>


<table class=" table-hover table-bordered tab">
    <tr>
        <th>id</th>
        <th>name</th>
        <th>description</th>
        <th>event_banner</th>
        <th>gallery id</th>
        <th>date</th>
        <th>username</th>
    </tr>
    <?php
    foreach (@$data as $key => $value): ?>

        <!-- `id`, `event_name`,`event_desc`, `event_banner`, `add_time` -->
        <tr>
            <td><?php echo $value['id']; ?></td>
            <td><?php echo $value['event_name']; ?>    </td>
            <td><?php echo $value['event_desc']; ?>    </td>
            <td><?php echo $value['event_banner']; ?>    </td>
            <td><?php echo $value['gallery_id']; ?>    </td>
            <td><?php echo $value['date']; ?>    </td>
            <td><?php echo $value['username']; ?>    </td>

            <td>
                <a href="?event=eventdelete&id=<?php echo $value['id']; ?> &banner=<?php echo $value['event_banner']; ?>"><img
                        src="../resources/images/cp/delete.png" alt="delete"></a>
                <a href="?event=editevent&id=<?php echo $value['id']; ?>"><img
                        src="../resources/images/cp/edit.png" alt="edit"> </a>

            </td>
        </tr>
        <?php
    endforeach;
    ?>
</table>