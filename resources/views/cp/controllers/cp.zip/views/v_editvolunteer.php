<h2>edit volunteer :</h2>


<form class="mainsettings" method="post" action="" enctype="multipart/form-data">
    <div><label>volunteer name :</label>
        <input type="text" name="name" value="<?php echo $data['name']; ?>" required>
    </div>
    <div><label>postion :</label>
        <input type="text" name="postion" value="<?php echo $data['postion']; ?>" required>
    </div>
    <div><label>volunteer image :</label>
        <input type="file" name="image[]" value=""  multiple="">
        <br>
        <img src="../resources/images/volunteers/<?php echo $data['image']?>" height="150px" >
        <br>
    </div>
    <div><label>some words :</label>
        <input type="text" name="words" value="<?php echo $data['words']; ?>" required>
    </div>
    <div><label>join date :</label>
        <input type="text" name="date" value="<?php echo $data['date']; ?>"></div>




    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
    <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
    <input class="btn-primary btn-lg" type="submit" name="volunteers" value="edit">

</form>

