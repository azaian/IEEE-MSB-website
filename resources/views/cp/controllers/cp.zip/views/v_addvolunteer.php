<h2>Add new volunteer :</h2>


<form class="mainsettings" method="post" action="" enctype="multipart/form-data">
    <div><label>event name :</label>
        <input type="text" name="name" value="" required>
    </div>
    <div><label>postion :</label>
        <input type="text" name="postion" value="" required>
    </div>
    <div><label>volunteer image :<br>(max 612*612)</label>
        <input type="file" name="image[]" value="" required multiple="">
    </div>
    <div><label>some words :</label>
        <input type="text" name="words" value="" required>
    </div>
    <div><label>join date :</label>
        <input type="text" name="date" value=""></div>

    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">
    <input class="btn-primary btn-lg" type="submit" name="volunteers" value="add">

</form>
