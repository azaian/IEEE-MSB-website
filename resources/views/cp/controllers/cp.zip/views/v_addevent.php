<h2>Add new event :</h2>


<form class="mainsettings" method="post" action="" enctype="multipart/form-data">
    <div><label>event name :</label>
        <input type="text" name="event_name" value="" required>
    </div>
<!--    <div><label>gallery id :</label>-->
<!--        <input type="text" name="gallery_id" value="" required></div>-->
    <div><label>event image <br>(th 360*170) :</label>
        <input type="file" name="event_image[]" multiple="" required></div>
    <div><label>event banner (960*361) :</label>
        <input type="file" name="event_banner[]" multiple="" required></div>
    <div><label>event date :</label>
        <input type="text" name="date" value=""></div>
    <div><label style="float:left;">event description :<br>to end = < br ></label>
        <textarea name="event_desc" value="" required></textarea></div>


    <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>">

    <input class="btn-primary btn-lg" type="submit" name="event" value="add">

</form>

