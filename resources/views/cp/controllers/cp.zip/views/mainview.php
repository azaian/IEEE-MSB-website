<!DOCTYPE html>
<html>
<head>
    <meta charset="UFT-8"/>
    <title>login page</title>
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="resources/css/cp-style.css">
    <script type="text/javascript" src="resources/js/bootstrap.min.js "></script>
    <script type="text/javascript" src="resources/js/bootstrap.js "></script>
</head>
<body>

<div class="container">
    <div class="contentlog">
        <!--        	<div class="registration">-->
        <!--        		<form action="" method="post">-->
        <!--        			<h1>resgiter new user: </h1>-->
        <!--        -->
        <!--        			<input 	name="username" type="text" placeholder="please write your username" >-->
        <!--        			<input  name="email"	type="email" placeholder="please write your email" >-->
        <!--        			<input 	name="password" type="password"  style="border-bottom:1px solid #000;">-->
        <!--        			<input 	type="submit" 	name="submit" value="register" >-->
        <!--        -->
        <!--        		</form>-->
        <!--        	</div>-->
        <div class="login center-block">
            <h1 class="text-center">- login -</h1>

            <form action="" method="POST" class="center-block">
                <input type="text" name="username" placeholder="username">
                <input type="password" name="password" placeholder="Password">

                <br>
                <input type="submit" name="submit" value="login">
            </form>
            <span id="error" class="center-block"></span>
        </div>
        <div class="clear"></div>
        <footer class='footer'>
            <p>
                copyright &copy reserved to abdelmnemsamy@gmail.com
            </p>
        </footer>
    </div>
</div>
<?php
include_once "cp/controllers/c_login.php";
?>
</body>
</html>