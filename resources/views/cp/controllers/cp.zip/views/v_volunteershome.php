<h3>volunteers </h3>
<table class=" table-hover table-bordered tab">
    <tr>
        <th>id</th>
        <th>name</th>
        <th>postion</th>
        <th>image</th>
        <th>words</th>
        <th>join date</th>
        <th>username</th>
    </tr>
    <?php
    foreach (@$data as $key => $value): ?>

        <!-- `id`, `event_name`,`event_desc`, `event_banner`, `add_time` -->
        <tr>
            <td><?php echo $value['id']; ?></td>
            <td><?php echo $value['name']; ?>    </td>
            <td><?php echo $value['postion']; ?>    </td>
            <td><?php echo $value['image']; ?>    </td>
            <td><?php echo $value['words']; ?>    </td>
            <td><?php echo $value['date']; ?>    </td>
            <td><?php echo $value['username']; ?>    </td>

            <td>
                <a href="?volunteers=volunteerdelete&id=<?php echo $value['id']; ?>&image=<?php echo $value['image']; ?>"><img
                        src="../resources/images/cp/delete.png" alt="delete"></a>
                <a href="?volunteers=editvolunteer&id=<?php echo $value['id']; ?>"><img
                        src="../resources/images/cp/edit.png" alt="edit"> </a>

            </td>
        </tr>
        <?php
    endforeach;
    ?>
</table>